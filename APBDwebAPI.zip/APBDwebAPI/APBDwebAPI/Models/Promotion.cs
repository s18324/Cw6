﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace APBDwebAPI.Models
{
    public class Promotion
    {
        public int Semester { get; set; }
        public string Studies { get; set; }
    }
}
